## How to play Bubble shooter game
- In order to shoot the bubbles click on the space bar.
- Any 3 consecutive  same color bubbles.
- Control the arrow  with left, right and up arrow keys. 
